-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2016 at 07:54 PM
-- Server version: 5.1.58
-- PHP Version: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bdspec2016_lfisetgrenier`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_prix`
--

CREATE TABLE IF NOT EXISTS `t_prix` (
  `id_prix` int(11) NOT NULL,
  `prix` float NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `id_menu` int(11) NOT NULL,
  PRIMARY KEY (`id_prix`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_prix`
--

INSERT INTO `t_prix` (`id_prix`, `prix`, `description`, `id_menu`) VALUES
(0, 12, '1 morceau', 0),
(1, 18, '2 morceaux', 0),
(2, 23, '3 morceaux', 0),
(3, 5.5, 'Extra (3oz)', 0),
(4, 18, '', 1),
(5, 20, '', 2),
(6, 20, '', 3),
(7, 12, 'Entrée', 4),
(8, 16, 'Repas', 4),
(9, 3, 'Extra poulet', 4),
(10, 12, 'Entrée', 5),
(11, 16, 'Repas', 5),
(12, 12, 'Entrée', 6),
(13, 16, 'Repas', 6),
(14, 16.95, '', 7),
(15, 16.95, '', 8),
(16, 17.95, '', 9),
(17, 4, '', 10),
(18, 6, '', 11),
(19, 10, 'Petite', 12),
(20, 16, 'Grand', 12),
(21, 3, 'Extra poulet, pulled pork ou lanières de steak', 12),
(22, 14, '', 13),
(23, 15, '', 14),
(24, 10, '', 15),
(25, 17, '', 16),
(26, 16, '', 17),
(27, 17, '', 18),
(28, 6, '', 21),
(29, 8, '', 22),
(30, 3.91, '10oz', 23),
(31, 7.39, '20oz', 23),
(32, 19.13, '60oz', 23),
(33, 3.91, '10oz', 24),
(34, 7.39, '20oz', 24),
(35, 19.13, '60oz', 24),
(36, 3.91, '10oz', 25),
(37, 7.17, '20oz', 25),
(38, 18.26, '60oz', 25),
(39, 3.91, '10oz', 26),
(40, 7.17, '20oz', 26),
(41, 18.26, '60oz', 26),
(42, 4.35, '10oz', 27),
(43, 8.05, '20oz', 27),
(44, 20.87, '60oz', 27),
(45, 3.91, '10oz', 28),
(46, 7.17, '20oz', 28),
(47, 18.26, '60oz', 28),
(48, 4.35, '10oz', 29),
(49, 8.05, '20oz', 29),
(50, 20.87, '60oz', 29),
(51, 3.91, '10oz', 30),
(52, 7.17, '20oz', 30),
(53, 19.13, '60oz', 30),
(54, 3.91, '10oz', 31),
(55, 7.39, '20oz', 31),
(56, 19.13, '60oz', 31),
(57, 3.91, '10oz', 32),
(58, 7.17, '20oz', 32),
(59, 18.26, '60oz', 32),
(60, 3.91, '10oz', 33),
(61, 7.17, '20oz', 33),
(62, 18.26, '60oz', 33),
(63, 4.35, '10oz', 34),
(64, 8.05, '20oz', 34),
(65, 4.35, '10oz', 35),
(66, 7.39, '20oz', 35),
(67, 4.35, '10oz', 36),
(68, 8.05, '20oz', 36),
(69, 7.39, '20oz', 37),
(70, 5.75, '10oz', 38),
(71, 7.17, '20oz', 39),
(72, 3.91, '10oz', 40),
(73, 7.17, '20oz', 40),
(74, 18.26, '60oz', 40),
(75, 3.91, '10oz', 41),
(76, 7.17, '20oz', 41),
(77, 18.26, '60oz', 41),
(78, 6.96, 'Verre', 42),
(79, 34, 'Bouteille', 42),
(80, 7.17, 'Verre', 43),
(81, 35, 'Bouteille', 43),
(82, 48, 'Bouteille', 44),
(83, 7.17, 'Verre', 45),
(84, 35, 'Bouteille', 45),
(85, 7.74, 'Verre', 46),
(86, 39, 'Bouteille', 46),
(87, 7.74, 'Verre', 47),
(88, 39, 'Bouteille', 47),
(89, 8.48, 'Verre', 48),
(90, 48, 'Bouteille', 48),
(91, 6.96, 'Verre', 49),
(92, 34, 'Bouteille', 49),
(93, 7.74, 'Verre', 50),
(94, 36, 'Bouteille', 50),
(95, 7.74, 'Verre', 51),
(96, 36, 'Bouteille', 51),
(97, 6.96, 'Verre', 52),
(98, 34, 'Bouteille', 52),
(99, 6.09, 'Verre', 53),
(100, 28, 'Bouteille', 53),
(101, 6.74, 'Verre', 54),
(102, 31, 'Bouteille', 54),
(103, 6.08, 'Bouteille', 55),
(104, 5.21, 'Bouteille', 56),
(105, 6.08, 'Bouteille', 57),
(106, 6.14, 'Bouteille', 58),
(107, 5.44, '', 59),
(108, 6.96, '', 60),
(109, 9.56, '', 61),
(110, 19.95, '', 62),
(111, 6.96, '', 63),
(112, 5.44, '', 64),
(113, 7.17, '', 65),
(114, 5.44, '', 66),
(115, 6.96, '', 67),
(116, 5.44, '', 68),
(117, 6.96, '', 69),
(118, 7.17, '', 70),
(119, 6.96, '', 71),
(120, 6.96, '', 72),
(121, 11.3, '', 73),
(122, 5.44, '', 74),
(123, 5.65, '', 75),
(124, 11.3, '', 76),
(125, 12.39, '', 77),
(126, 7.17, '', 78),
(127, 7.17, '', 79),
(128, 8.7, '', 92);

-- --------------------------------------------------------

--
-- Table structure for table `t_promotions`
--

CREATE TABLE IF NOT EXISTS `t_promotions` (
  `id_promotion` int(11) NOT NULL,
  `nom_promotion` text CHARACTER SET utf8 NOT NULL,
  `description_promotion` longtext CHARACTER SET utf8 NOT NULL,
  `etat_promotion` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_promotion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `t_repas`
--

CREATE TABLE IF NOT EXISTS `t_repas` (
  `id_menu` int(11) NOT NULL,
  `nom_plat` text CHARACTER SET utf8 NOT NULL,
  `description_plat` mediumtext CHARACTER SET utf8 NOT NULL,
  `etat_plat` text CHARACTER SET utf8 NOT NULL,
  `id_type` int(11) NOT NULL,
  `id_prix` int(11) NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_repas`
--

INSERT INTO `t_repas` (`id_menu`, `nom_plat`, `description_plat`, `etat_plat`, `id_type`, `id_prix`) VALUES
(0, 'Fish and Chips', 'Filets d’aiglefin panés dans notre \r\nunique recette de pâte à la bière de \r\ntype Ale,  frites maison, salade de \r\nchoux, sauce tartare et cornichons', 'actif', 0, 0),
(1, 'Irish stew braisé à la Guiness', 'Accompagné d’une salade et soda bread', 'actif', 0, 0),
(2, 'Tartare de boeuf', 'Entrecôte hachée à la minute, assaisonnée à \r\nvotre goût. Servi avec croûtons, frites maison, \r\nou salade', 'actif', 0, 0),
(3, 'Tartare de saumon', 'Servi avec frites maison ou salade et croûtons', 'actif', 0, 0),
(4, 'César', 'Laitue romaine, parmesan, croûtons et bacon\r\nmaison, sauce crémeuse', 'actif', 8, 0),
(5, 'Grecque', 'Fromage feta, oignons rouges, olives kalamata, concombre anglais, tomates, poivrons verts et huile d’olive', 'actif', 8, 0),
(6, 'Molly Malone', 'Raisins rouges, pommes, concombre anglais, \ntomates, bacon, pacanes, fromage \ncheddar râpé et vinaigrette balsamique et \nsirop d’érable', 'actif', 8, 0),
(7, 'Dunbrody', 'Poulet, bacon, fromage brie, tomates, laitue avec moutarde au miel', 'actif', 9, 0),
(8, 'Jeanie', 'Pulled pork et fromage suisse', 'actif', 9, 0),
(9, 'Trinity', 'Crabe et avocat, tomates, salade', 'actif', 9, 0),
(10, 'Bretzel moutarde bière et miel', '', 'actif', 1, 0),
(11, 'Les pommes de terres frites maison', '', 'actif', 1, 0),
(12, 'Poutine irlandaise', 'Frites, sauce irlandaise au whiskey, fromage cheddar en grain et pois verts Saucisses de porc ou pulled pork ou bacon ou smoked meat', 'actif', 1, 0),
(13, 'Ailes de poulet', 'Sauce au bleu et crudités \r\n(Sweet Molly, buffalo ou hell’s kitchen)\r\n6 morceaux', 'actif', 1, 0),
(14, 'Nachos Claddagh', 'Tortillas cuits maison, servis avec olives noires, tomates, salsa, crème sure et fromage gratiné', 'actif', 1, 0),
(15, 'Assiette de saumon fumé', 'Oignons rouges, câpres, huile d’olive', 'actif', 1, 0),
(16, 'Crab cake', 'Chair de crabe assaisonnée, accompagnée de\r\nmayo épicée, poivrons confits et salade	', 'actif', 1, 0),
(17, 'Oignons frits à la bière et son caramel à la Guiness', '', 'actif', 1, 0),
(18, 'Assiette de cochonnailles et fromages', 'Saucisson sec, pâté de foie de volaille à \r\nl’érable, fromage à la Guinness, oignons \r\ncaramélisés et croûtons', 'actif', 1, 0),
(19, 'Le Danny Collin', '8 oz, salade de choux, cornichon, frites maison ou salade. Choix de moutarde.', 'actif', 10, 0),
(20, 'Le Ruebens', '8 oz, salade de choux, fromage suisse et\r\nchoucroute, cornichon, frites maison ou salade.', 'actif', 10, 0),
(21, 'Crème brûlée à la crème irlandaise', '', 'actif', 2, 0),
(22, 'Gâteau au fromage New York style\r\navec son coulis ', '', 'actif', 2, 0),
(23, 'L''Alchimiste scotch ale', '', 'actif', 11, 0),
(24, 'Goose Honkers ale', '', 'actif', 11, 0),
(25, 'Griffon rousse', '', 'actif', 11, 0),
(26, 'St-Ambroise cream ale', '', 'actif', 11, 0),
(27, 'Smithwick’s', '', 'actif', 11, 0),
(28, 'Cheval blanc', '', 'actif', 12, 0),
(29, '1664 Kronenbourg', '', 'actif', 12, 0),
(30, 'Les Vergers de la Colline', '', 'actif', 13, 0),
(31, 'L’ Alchimiste', '', 'actif', 14, 0),
(32, 'Carlsberg', '', 'actif', 15, 0),
(33, 'Samuel Adams', '', 'actif', 15, 0),
(34, 'Guinness', '', 'actif', 16, 0),
(35, 'Black and tan', 'Guinness-Griffon Rousse', 'actif', 17, 0),
(36, 'Guinness black', 'Guinness-Casis', 'actif', 17, 0),
(37, 'Half and Half', 'Guinness-Carlsberg', 'actif', 17, 0),
(38, 'Irish car bomb', 'Guinness-Crème irlandaise-Jameson', 'actif', 17, 0),
(39, 'Poorman black velvet', 'Guinness-Cidre', 'actif', 17, 0),
(40, 'Snake bite', 'Carlsberg-Cidre', 'actif', 17, 0),
(41, 'Snake bite black', 'Carlsberg-Cidre-Casis', 'actif', 17, 0),
(42, 'Barbera D’Asti', 'Costalunga, Piedmont, Italie', 'actif', 3, 0),
(43, 'Campo Viejo Rioja', 'Espagne', 'actif', 3, 0),
(44, 'Château St-Jean Californie', ' Cab. Sauvignon, États-Unis', 'actif', 3, 0),
(45, 'Coronas, Tempranillo', 'Espagne', 'actif', 3, 0),
(46, 'Gabbiano Chianti', 'Italie', 'actif', 3, 0),
(47, 'Jacob’s creek', ' Shiraz cabernet, Australie', 'actif', 3, 0),
(48, 'Château St-Jean', 'Chardonnay, Californie', 'actif', 4, 0),
(49, 'Graffigna Centenario', 'Pinot grigio, Argentine', 'actif', 4, 0),
(50, 'Jacob’s Creek ', 'Semillion Chardonnay, Australie', 'actif', 4, 0),
(51, 'Torres Gran Vina Sol', 'Chardonnay 2013, Espagne', 'actif', 4, 0),
(52, 'Lamura', 'Italie', 'actif', 6, 0),
(53, 'Nobella de Espana', 'Espagne', 'actif', 18, 0),
(54, 'Sangria', 'rouge ou blanche', 'actif', 18, 0),
(55, 'Bitburger sans alcool', '', 'actif', 19, 0),
(56, 'Bud Light-Bud', '', 'actif', 19, 0),
(57, 'Stella Artois', '', 'actif', 19, 0),
(58, 'Smirnoff Ice', '', 'actif', 19, 0),
(59, 'Bushmills', '', 'actif', 5, 0),
(60, 'Bushmills 10 ans', '', 'actif', 5, 0),
(61, 'Bushmills 16 ans', '', 'actif', 5, 0),
(62, 'Bushmills 21 ans', '', 'actif', 5, 0),
(63, 'Connemara Peated ', 'Selon les disponibilités', 'actif', 5, 0),
(64, 'Jameson', '', 'actif', 5, 0),
(65, 'Jameson select', '', 'actif', 5, 0),
(66, 'Kilbeggan', '', 'actif', 5, 0),
(67, 'Knappogue Castle 12 ans single malt', '', 'actif', 5, 0),
(68, 'Powers', 'Selon les disponibilités', 'actif', 5, 0),
(69, 'Teeling Whiskey Small Batch', '', 'actif', 5, 0),
(70, 'The Wild Geese Irish Soldiers & Heroes', '', 'actif', 5, 0),
(71, 'Tullamore Dew 12 ans Special Reserve', '', 'actif', 5, 0),
(72, 'Tyrconnell', '', 'actif', 5, 0),
(73, 'Tyrconnell 10 ans', 'Selon les disponibilités', 'actif', 5, 0),
(74, 'Bulleit Frontier Bourbon', '', 'actif', 20, 0),
(75, 'Maker''s Mark Kentucky Bourbon', '', 'actif', 20, 0),
(76, 'Ardberg 10 ans, Islay', '', 'actif', 20, 0),
(77, 'Aberlour cask A''bunadh Speyside', '', 'actif', 20, 0),
(78, 'Auchentoshan 12 ans, Lowland', '', 'actif', 20, 0),
(79, 'Bowmore 12 ans, Islay', '', 'actif', 20, 0),
(80, 'Cardhu Speyside single malt', '', 'actif', 20, 0),
(81, 'Chivas 12 ans', '', 'actif', 20, 0),
(82, 'Chivas 18 ans', '', 'actif', 20, 0),
(83, 'GlenFarclas 12 ans Highland', '', 'actif', 20, 0),
(84, 'GlenFiddich 12 ans, Highland', '', 'actif', 20, 0),
(85, 'GlenFiddich 18 ans, Highland', '', 'actif', 20, 0),
(86, 'GlenLivet 12 ans, Highland', '', 'actif', 20, 0),
(87, 'GlenLivet 18 ans, Highland', '', 'actif', 20, 0),
(88, 'Johnny Walker red', '', 'actif', 20, 0),
(89, 'Johnny Walker black', '', 'actif', 20, 0),
(90, 'Lagavulin 16 ans, Islay', '', 'actif', 20, 0),
(91, 'Laphroaig 10 ans, Islay', '', 'actif', 20, 0),
(92, 'Macallan gold, Higland', '', 'actif', 20, 0);

-- --------------------------------------------------------

--
-- Table structure for table `t_types`
--

CREATE TABLE IF NOT EXISTS `t_types` (
  `id_type` int(11) NOT NULL,
  `nom_type` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `t_types`
--

INSERT INTO `t_types` (`id_type`, `nom_type`) VALUES
(0, 'Plat principal'),
(1, 'Entrée'),
(2, 'Dessert'),
(3, 'Vin rouge'),
(5, 'Whiskey Irlande'),
(11, 'Ale'),
(7, 'Autres'),
(8, 'Salade'),
(9, 'Panini'),
(10, 'Smoked meat'),
(12, 'Blanche'),
(13, 'Cidre'),
(14, 'I.P.A'),
(15, 'Lager'),
(16, 'Stout'),
(17, 'Mélange celtique'),
(4, 'Vin blanc'),
(6, 'Vin rosé'),
(18, 'Vin maison'),
(19, 'Bière bouteille'),
(20, 'Whiskey États-Unis'),
(21, 'Whiskey Écosse');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
